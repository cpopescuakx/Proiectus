package com.example.myapplication;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginRequest extends JsonObjectRequest {

    private static final String LOGIN_REQUEST_URL = "https://proiectus.cat/g1_android/validate_user.php";
    private Map<String, String> params;

    public LoginRequest(String user, String pwd, Response.Listener<JSONObject> listener) {
        super(LOGIN_REQUEST_URL, null, listener, null);
        params = new HashMap<>();
        params.put("user", user);
        params.put("pwd", pwd);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
